---
name: Bug report
about: Create a report to help Project Manager improve
title: "[BUG] - "
labels: bug
assignees: ''

---

<!-- Please search existing issues to avoid creating duplicates. -->

<!-- Use Help > Report Issue to prefill some of these. -->
**Environment/version**

- Extension version:
- VSCode version: 
- OS version: 

**Steps to reproduce**

1. 
2. 
