## Organize with Tags

You can organize/categorize your projects using **Tags**. Filter your projects by **Tags** and even choose active **Tags** that are more relevant to the work you are doing.

![Organize with Tags](../images/vscode-project-manager-side-bar-tags.gif)