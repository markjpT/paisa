## Localize e Abra Seus Projetos

Você pode acessar rapidamente todos os seus projetos na **Paleta de Comandos**, usando o comando `Project Manager: Listar Projetos para Abrir`, ou na **Barra Lateral** exclusiva.

Para acessar os projetos via **Paleta de Comandos**, você também pode usar os atalhos de teclado nativos <kbd>Shift</kbd> + <kbd>Alt</kbd> + <kbd>P</kbd> / <kbd>Cmd</kbd> + <kbd>Alt</kbd> + <kbd>P</kbd> (no MacOS).

Os projetos podem ser filtrados por nome ou caminho.

### Paleta de Comando

![Listar](../images/project-manager-list-sort-by-name.png)