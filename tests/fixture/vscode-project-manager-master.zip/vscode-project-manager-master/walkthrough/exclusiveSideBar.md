## Exclusive Side Bar

An exclusive **Side Bar** with a variety of commands to improve you productivity. 

![Side Bar](../images/vscode-project-manager-side-bar.png)