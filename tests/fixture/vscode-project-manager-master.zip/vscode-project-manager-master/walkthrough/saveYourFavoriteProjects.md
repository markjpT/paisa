## Save your Favorite Projects

You can save the current folder or workspace as a **Project** at any time. You just need to type its name. 

![Save](../images/project-manager-save.png)

It _automatically_ suggests the name of the project with the name of the folder / workspace you have opened, as a shortcut.

Once you save it, it will be available in the **Command Palette** and the exclusive **Side Bar**.