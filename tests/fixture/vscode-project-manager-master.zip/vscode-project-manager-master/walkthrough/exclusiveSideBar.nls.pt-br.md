## Barra Lateral Exclusiva

Uma **Barra Lateral** exclusiva com uma variedade de comandos para aumentar sua produtividade. 

![Barra Lateral](../images/vscode-project-manager-side-bar.png)